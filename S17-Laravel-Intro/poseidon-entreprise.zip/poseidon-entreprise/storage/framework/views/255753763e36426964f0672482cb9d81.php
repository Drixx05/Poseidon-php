<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Fiche service</title>
</head>
<body>
    <p>Vous consultez le service n°<?php echo e($service['id']); ?>.</p>

    <?php if($service): ?>
        <ul>
            <li>Nom : <?php echo e($service['nom']); ?></li>
            <li>Responsable : <?php echo e($service['responsable']); ?></li>
            <li>Téléphone : <?php echo e($service['telephone']); ?></li>
        </ul>
    <?php endif; ?>

    <a href="<?php echo e(route('services.index')); ?>">Retour à la liste</a>
</body>
</html><?php /**PATH /home/drixx/Poseidon-php/S17-Laravel-Intro/poseidon-entreprise/resources/views/services/show.blade.php ENDPATH**/ ?>