<nav>
    <a href="<?php echo e(route('welcome')); ?>">Accueil</a> |
    <a href="<?php echo e(route('employees.index')); ?>">Employés</a> |
    <a href="<?php echo e(route('services.index')); ?>">Services</a> |
    <a href="<?php echo e(route('contact.index')); ?>">Contact</a>
</nav><?php /**PATH /home/drixx/Poseidon-php/S17-Laravel-Intro/poseidon-entreprise/resources/views/layout/nav.blade.php ENDPATH**/ ?>