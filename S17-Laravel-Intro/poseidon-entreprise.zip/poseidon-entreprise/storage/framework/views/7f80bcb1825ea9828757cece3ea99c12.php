<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Employés</title>
</head>
<body>
    <h1>Page Employés</h1>
</body>
</html><?php /**PATH /home/drixx/Poseidon-php/S17-Laravel-Intro/poseidon-entreprise/resources/views/employees/index.blade.php ENDPATH**/ ?>